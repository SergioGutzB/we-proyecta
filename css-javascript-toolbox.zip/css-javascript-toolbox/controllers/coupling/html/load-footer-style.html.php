<?php
/**
* @version $ Id; blocks-coupling.php 21-03-2012 03:22:10 Ahmed Said $
*/
		
// Disallow direct access.
defined('ABSPATH') or die("Access denied");

?>
<script type="text/javascript">
	var cjt_footer_linked_stylesheets = <?php echo $jsStyleSheetsList ?>;
</script>