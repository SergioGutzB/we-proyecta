<?php
/**
* 
*/
class CJTServicesAPICallException extends Exception {}
