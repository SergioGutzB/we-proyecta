<?php
/**
* 
*/

/**
* 
*/
interface CJTServicesIPluginBase {
	
	/**
	* 
	*/
	public function & getController($serviceConfig);
	
}