<?php
/**
* 
*/

/**
* 
*/
class CJT_Framework_DB_Mysql_Driver_Exception_Invalidkey extends Exception {}