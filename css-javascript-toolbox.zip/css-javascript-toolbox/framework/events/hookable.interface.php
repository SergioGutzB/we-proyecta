<?php
/**
* 
*/

/**
* 
*/
interface CJTIHookable {}
