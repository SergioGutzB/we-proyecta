<?php
/**
* 
*/

/**
* 
*/
class CJT_Framework_View_Block_Parameter_Renderer_Checkbox_Checkbox
extends CJT_Framework_View_Block_Parameter_Base_Scalar {} // End class.