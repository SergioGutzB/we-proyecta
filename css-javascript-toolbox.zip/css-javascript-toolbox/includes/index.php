<?php
/**
*  index.php just to prevent indexing of plugin folder
* 
* This directory used to hold the common library
* that might be used in various areas only for this version.
* 
*/
