<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Frag_Frag_Block_Params_List_Param_Params
extends CJT_Models_Package_Xml_Definition_Abstract {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $map = array('param' => 'frag/block/params/list/param');
	
} // End class