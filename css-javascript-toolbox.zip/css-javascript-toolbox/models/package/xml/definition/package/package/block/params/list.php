<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Package_Package_Block_Params_List
extends CJT_Models_Package_Xml_Definition_Frag_Frag_Block_Params_List {} // End class