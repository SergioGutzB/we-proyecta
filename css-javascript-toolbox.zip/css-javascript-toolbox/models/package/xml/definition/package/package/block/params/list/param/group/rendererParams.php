<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Package_Package_Block_Params_List_Param_Group_RendererParams
extends CJT_Models_Package_Xml_Definition_Frag_Frag_Block_Params_List_Param_Group_RendererParams {
	
	/**
	* put your comment there...
	* 
	* @var mixed
	*/
	protected $map = array('param' => 'package/block/params/list/param/typeParams/param');

} // End class