/**
* 
*/

/**
* 
*/
(function($) {
	
	/**
	* Override CJTBlockPlugin class.
	* 
	* @param node
	* @param args
	*/
	CJTBlockPlugin = function(node, args) {
		// Code has been removed to CJTe Editor Toolbox extension
		// .
		// .
		// .
		// Initialize base class.
		this.initCJTPluginBase(node, args);
			
	} // End class.
	
	// Extend CJTBlockPlugin class.
	CJTBlockPlugin.prototype = new CJTBlockPluginBase();
})(jQuery);