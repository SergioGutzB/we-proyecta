/**
* 
*/

/**
* 
*/
(function($) {
	
	/**
	* 
	*/
	$(function() {
		// Make Dashboard metabox unclickable		
		$('#cjt-statistics h3,#cjt-statistics .handlediv').unbind('click.postboxes');
	});
})(jQuery);